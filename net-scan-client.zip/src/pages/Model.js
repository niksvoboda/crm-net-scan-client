import React from "react";


const Model = () =>{

    return(
        <div>
            Модель
        </div>
    )
}

export default Model;