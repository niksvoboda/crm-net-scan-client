import React from "react";


const Audit = () =>{

    return(
        <div>
            Аудит
        </div>
    )
}

export default Audit;