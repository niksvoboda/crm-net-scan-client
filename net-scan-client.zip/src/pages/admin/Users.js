import React from "react";


const Users = () =>{

    return(
        <div>
           настройки пользователей
        </div>
    )
}

export default Users;