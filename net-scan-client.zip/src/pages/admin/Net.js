import React from "react";


const Net = () =>{

    return(
        <div>
           Сетевые настройки
        </div>
    )
}

export default Net;