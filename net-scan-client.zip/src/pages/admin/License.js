import React from "react";


const License = () =>{

    return(
        <div>
           Лицензия
        </div>
    )
}

export default License;